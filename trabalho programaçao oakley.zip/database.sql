-- SQLite database file: database.sqlite
-- Created by Pony ORM

PRAGMA foreign_keys = ON;

CREATE TABLE "Roupa" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "nome" TEXT NOT NULL,
    "descricao" TEXT NOT NULL,
    "preco" REAL NOT NULL,
    "imagem" TEXT NOT NULL,
    "categoria" TEXT NOT NULL
);