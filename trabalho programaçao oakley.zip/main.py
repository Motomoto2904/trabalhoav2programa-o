from flask import Flask, render_template, request, redirect, url_for
from pony.orm import db_session, select

app = Flask(__name__)

# Configuração do banco de dados
db = db_session(provider='sqlite', filename='database.sqlite', create_db=True)

# Classe para registrar
class Roupa(db.Entity):
    id = PrimaryKey(int, auto=True)
    nome = Required(str)
    descricao = Required(str)
    preco = Required(float)
    imagem = Required(str)
    categoria = Required(str)

# Rota para a página de index
@app.route("/")
def index():
    return render_template("index.html")

# Rota para a página de registro
@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        roupa = Roupa(
            nome=request.form["nome"],
            descricao=request.form["descricao"],
            preco=request.form["preco"],
            imagem=request.form["imagem"],
            categoria=request.form["categoria"]
        )
        db.commit()
        return redirect(url_for("index"))
    return render_template("registro.html")

if __name__ == "__main__":
    app.run(debug=True)